import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';

class SearchAssetsSection extends Component {
    render() {
        return (
            <React.Fragment>
                <Grid container>
                    <Grid item xs={12} sm={12} md={12}>
                        search assets
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}

export default SearchAssetsSection;