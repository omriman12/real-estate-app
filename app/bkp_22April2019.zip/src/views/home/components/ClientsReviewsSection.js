import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';

class ClientsReviewsSection extends Component {
    render() {
        return (
            <React.Fragment>
                <Grid container>
                    <Grid item xs={12} sm={12} md={12}>
                        clients revies
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}

export default ClientsReviewsSection;