import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';

class SearchAssetsForm extends Component {
    render() {
        return (
            <React.Fragment>
                search assets form
            </React.Fragment>
        );
    }
}

export default SearchAssetsForm;